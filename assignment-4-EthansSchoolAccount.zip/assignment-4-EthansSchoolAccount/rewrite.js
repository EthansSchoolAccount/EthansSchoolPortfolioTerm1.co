var fs = require('fs');
var readlineSync = require('readline-sync');//loading readlinesync and fs before starting the loop so they can be accessed without needing the function

function main() {
    var linkTocsv = "C:/Users/School/Documents/VS Code/Logic and Programming/assignment-4-EthansSchoolAccount/the_choices_file.csv";

    var linkTotxt = "C:/Users/School/Documents/VS Code/Logic and Programming/assignment-4-EthansSchoolAccount/the_story_file.txt"; //getting the files linked 

    var storyToEdit = fs.readFileSync(linkTotxt, "utf-8");

    var data = fs.readFileSync(linkTocsv, "utf-8"); //porting them into the software

    data = data.replaceAll('\r',"")
    data = data.replaceAll('\n',",")
    var lines = data.split(',') //splitting everything up so it can be reorganized 
    block1 = [] //making the arrays for later
    block2 = []
    block3 = []
    block4 = []
    block5 = []
    block6 = []
    block7 = []

    for (i = 0; i < lines.length; i++) { //counting through every step to sort them into their proper arrays (it wouldnt let me split them after the fact and without functions this is the best I could do)
        if (i == 0 || i == 1 || i == 2 || i == 3 || i == 4 || i == 5) {
            block1.push(lines[i])
        }
        else if (i == 6 || i == 7 || i == 8 || i == 9 || i == 10 || i == 11) {
            block2.push(lines[i])
        }
        else if (i == 12 || i == 13 || i == 14 || i == 15 || i == 16 || i == 17) {
            block3.push(lines[i])
        }
        else if (i == 18 || i == 19 || i == 20 || i == 21 || i == 22 || i == 23) {
            block4.push(lines[i])
        }
        else if (i == 24 || i == 25 || i == 26 || i == 27 || i == 28 || i == 29) {
            block5.push(lines[i])
        }
        else if (i == 30 || i == 31 || i == 32 || i == 33 || i == 34 || i == 35) {
            block6.push(lines[i])
        }
        else if (i == 36 || i == 37 || i == 38 || i == 39 || i == 40 || i == 41) {
            block7.push(lines[i])
        }
    }
    var letterAnswerKey = ["A", "B", "C", "D", "E"] //making the correct answers easier to call later
    var userChoice = readlineSync.question("please choose a animal:\na) aardvark\nb) hippo\nc) duck\nd) pelican\ne) t-rex\nenter your choice (a-e): "); //getting ht user input the first time

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) { //this checks if the users input matches any of the possible answers, if it doesnt then it gets you to try again
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) { //since it knows the answer has to be right it just counts through them until one matches, where it then writes the actual selection in
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block1[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_1_", userChoice.toLocaleUpperCase()) //replaces the blanks with the answer the user gave
    //second batch without function it needed to be copy pasted in 7 times without minor changes in each, they all do the same thing
    userChoice = readlineSync.question("please choose an action word ending in 'ed':\na) jumped\nb) flipped\nc) looked\nd) added\ne) squashed\nEnter your choice (a-e): ");

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) {
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling)\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) {
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block2[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_2_", userChoice.toLocaleUpperCase())
    //third batch
    userChoice = readlineSync.question("please choose an adjective:\na) impressive\nb) slimy\nc) silly\nd) frozen\ne) magical\nEnter your choice (a-e): ");

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) {
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling)\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) {
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block3[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_3_", userChoice.toLocaleUpperCase())
    //fourth batch
    userChoice = readlineSync.question("please choose another action word ending in 'ed':\na) exploded\nb) scattered\nc) flapped\nd) snooped\ne) poked\nEnter your choice (a-e): ");

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) {
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling)\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) {
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block4[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_4_", userChoice.toLocaleUpperCase())
    //fifth batch
    userChoice = readlineSync.question("please choose a noun:\na) president\nb) pastry chef\nc) karate\nd) beer mug\ne) tank\nEnter your choice (a-e): ");

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) {
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling)\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) {
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block5[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_5_", userChoice.toLocaleUpperCase())
    //sixth batch
    userChoice = readlineSync.question("please choose another action word ending in 'ed':\na) messed\nb) smacked\nc) tripped\nd) danced\ne) slurped\nEnter your choice (a-e): ");

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) {
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling)\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) {
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block6[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_6_", userChoice.toLocaleUpperCase())
    //seventh batch
    userChoice = readlineSync.question("please choose an adverb:\na) dreadfully\nb) happily\nc) stupidly\nd) awkwardly\ne) beautifully\nEnter your choice (a-e): ");

    while (!letterAnswerKey.includes(userChoice.toUpperCase())) {
        userChoice = readlineSync.question("Invalid answer, please try again (check spelling)\nEnter your choice (a-e): ");
    }
    for (i = 0; i < letterAnswerKey.length; i++) {
        if (userChoice.toUpperCase() === letterAnswerKey[i]) {
            i = i + 1
            userChoice = block7[i]
            break;
        }
    }
    storyToEdit = storyToEdit.replaceAll("_7_", userChoice.toLocaleUpperCase())
    
    //ending 
    console.log(storyToEdit) //it then just prints the output
}
    

main()