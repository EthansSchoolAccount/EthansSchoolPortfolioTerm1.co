//to begin I would setup fs and load and setup anything else I will need later in the program
//then I will load and split each line from the txt into a array
//then I will loop and check if it has the right amount of characters or if it is to be removed by math.random
//then I save the new edited version to a new txt and print them out using console.log


var fs = require('fs');

var charEncoding = "utf8";

var linkTotxt = "Assignment4-InputFiles/ateam_Original.txt";

originalText = fs.readFileSync(linkTotxt,charEncoding) //loading in everthing I need then putting the text from the txt into a string

modifiedFile = "Assignment4-InputFiles/ateam_Modified.txt" //setting up the txt that the edited text will go

textArrayed = originalText.split("\r\n") //putting each line into a array

countedArray = []

randomNum = Math.random() * 9 + 1 //doing final setup for the big loop that will handle everything

function lineChecker(progress) { //the function that holds everything 
    lettercount = textArrayed[progress]; //setting a "lettercount" to be a single line from the full array with nothing else so it can be checked
    
    if (textArrayed[progress] <= 20) {
        textArrayed[progress] = lettercount.toUpperCase(); //this counts how many characters are in the line and if it's under it sets them to caps then rewrites array to include the new version
    }
    
    else if (textArrayed[progress] > 20) {
        textArrayed[progress] = lettercount.toLowerCase(); //same as the first "if" but checking if it's over the character limit and setting it to lowercase if it is
    }
    
    countedArray.push(`${progress+1}: ${textArrayed[progress]}`) //putting the numbers into the beginning of each line 

    if (progress + 1 == randomNum.toFixed()) {
        countedArray[progress] = countedArray[progress].replaceAll(countedArray[progress]," "); //checking if the loop is on the number that matches the math.random set earlier, if it is it replaces all the text with a single " "
    }
}
for (i = 0; i < textArrayed.length; i++) {
    progress = i //setting up the parameter for the function
    lineChecker(progress)//the function with the parameter set prior
}

fs.writeFileSync(modifiedFile,countedArray.join("\n"), charEncoding);//putting the text from the array into the file

modifiedText = fs.readFileSync(modifiedFile,charEncoding) //loading the file just created so it can be displayed as a string

console.log(`---------------------------------------\nOriginal Text\n---------------------------------------`)
console.log(originalText)
console.log(`---------------------------------------\nAltered Text\n---------------------------------------`) //printing the final info 
console.log(modifiedText)